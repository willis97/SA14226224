学号：SA14226291

姓名：张庆梅

班级：软设2班

编译：gcc testcase.c linktable.c SA291menu.c testSA291menu.c -o test

运行：./test
